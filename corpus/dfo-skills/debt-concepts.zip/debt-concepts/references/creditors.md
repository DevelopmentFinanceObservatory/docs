# Creditors

What this covers: the creditor groups used in debt analysis, how bilateral creditors divide between the Paris Club and others, and the repayment structures that shape when principal falls due.

## Creditor groups

Multilateral creditors are institutions owned by several governments, such as IDA, IBRD, the African and Asian Development Banks, and the IMF. Bilateral creditors are governments and their agencies, including export credit agencies and development banks. Private creditors are bondholders, commercial banks, and other private lenders, among them commodity traders.

The Paris Club is a group of creditor governments that coordinate their debt restructurings. Its 22 permanent members are Australia, Austria, Belgium, Brazil, Canada, Denmark, Finland, France, Germany, Ireland, Israel, Italy, Japan, the Netherlands, Norway, the Republic of Korea, the Russian Federation, Spain, Sweden, Switzerland, the United Kingdom, and the United States, with Brazil and Korea permanent members since 2016. A Paris Club total is the sum of debt owed to these creditor countries, and bilateral debt to every other government, including China, India, Saudi Arabia, and Türkiye, is non-Paris Club debt.

## Repayment structures

A loan's repayment structure sets when its principal falls due, and projected debt service on signed loans follows each loan's schedule.

- Bullet. The borrower pays interest only until maturity and repays the whole principal in one payment. Most Eurobonds, government bonds sold to international investors and usually issued in US dollars or euros under New York or English law, repay this way, so each maturity causes a one-year spike in principal to bondholders. Some bonds instead repay in equal instalments over their last two or three years, which spreads the spike over those years.
- Amortising after a grace period. The borrower pays interest only during the grace period and then repays principal in roughly equal instalments until maturity. Most multilateral and official bilateral loans repay this way, so principal to official creditors runs smoothly from year to year, and a burst of new official borrowing reaches principal only once its grace periods end.

In debt data, the structures show by creditor type. Principal to bondholders peaks in maturity years, and principal to official creditors changes gradually. The average maturity and grace period on new commitments show the schedule that recent borrowing will follow. A country meets a bullet maturity by refinancing with new borrowing or by paying from reserves, so a maturity year is a refinancing risk that depends on market access in that year. Borrowing not yet signed has no schedule in the data.
